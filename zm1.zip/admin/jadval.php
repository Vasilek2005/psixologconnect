<?php
session_start();
if (!(isset($_SESSION['login']) && $_SESSION['login'])) {
  header('Location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>
<body>

<?php

             $surov = "SELECT * FROM `clients` WHERE 1";
   
    
             include_once "../connect.php";
             $query = mysqli_query($con,$surov);
       ?>
        <div class="row">
              <div class="col-md-3">
              <a role="button" class="btn btn-primary" href="create.php">
                          Ma'lumot qo'shish
                        </a>
              </div>
            </div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
       
      <th scope="col">Kun</th>
      <th scope="col">Muammosi</th>
    </tr>
  </thead>
  <tbody>
  <?php
                   $i = 1;
                     while($row = mysqli_fetch_assoc($query)) {  
                   ?>          
                    
                    <tr>
                      <th scope="row"><?=$i?></th>
                      <td><?=$row['ism']?></td>
                      
                      <td><?=$row['yoshi']?></td>
                      <td><?=$row['muammo']?></td>
                      <td>
                        <a role="button" class="btn btn-primary" href="ozgartirish.php?id=<?=$row['id']?>">
                          O'zgartirish
                        </a>
                      </td>
                      <td>
                        <a role="button" class="btn btn-danger" href="delete.php?id=<?=$row['id']?>">
                          O'chirish
                        </a>
                      </td>
                    </tr>

                    <?php
                    $i++;
                     }
                    ?>
  </tbody>
</table>
<a href="logout.php" class="nav-item nav-link"
              ><i class="fa fa-chart-bar me-2"></i>Tizimdan chiqish</a
            >

</body>
</html>