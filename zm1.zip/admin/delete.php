<?php
session_start();
if (!(isset($_SESSION['login']) && $_SESSION['login'])) {
  header('Location:login.php');
}

    if (isset($_GET['id'])) {
        $id = $_GET['id'];
       include "../connect.php";
       $surov = "DELETE FROM clients WHERE id='$id'";
       $query = mysqli_query($con,$surov);
       header('Location:jadval1.php');
    } else{
        echo "xatolik bor";
    }
?>