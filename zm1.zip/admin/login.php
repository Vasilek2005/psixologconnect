<?php
session_start();
include_once "../connect.php";
if (isset($_POST['login']) && isset($_POST['pass'])) {
  $login=$_POST['login'];
  $pass=$_POST['pass'];
  $surov = "SELECT user, pass from therapists where user='$login' AND pass='$pass' LIMIT 1";
  $query = mysqli_query($con, $surov);

  $row= mysqli_fetch_assoc($query);
  if (mysqli_num_rows($query) >= 1) {
    $_SESSION['login']=true;
    $_SESSION['user']= mysqli_fetch_assoc($query)[0];
  header('Location:jadval1.php');
  }else {
    echo "-";
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <!-- Spinner Start -->
       
        <!-- Spinner End -->
        <div class="row mt-5 py-5">
        <div class="col-4"></div>
        <div class="col-4">
        <form action="" method="post">
     
            <div class="mb-3">
              <label for="exampleInputEmail1" class="form-label">Log in</label>
              <input type="text" name="login" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            </div>
            <div class="mb-3">
              <label for="exampleInputPassword1" class="form-label">Password</label>
              <input type="password" name="pass" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="row">
            <div class="col-4"><button type="submit" class="btn btn-primary">Submit</button></div>
            <div class="col-4"></div>
            <div class="col-4"><a href="registratsiya.php" class="nav-item nav-link"></i>Registratsiya</a>
</div>
            </div>
            
          </form>
</div>
<div class="col-4"></div>
    </div>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
