<?php
        $sorov = "SELECT * FROM `therapists` ORDER BY id ASC LIMIT 6;";
        include_once "connect.php";
        $query = mysqli_query($con,$sorov);
    ?>    
<div id="therapists" class="basic-4">
<div class="row">
                <div class="col-lg-12">
                <h2 class="h2-heading" style="margin-bottom: 0.75rem; text-align: center;">Terapevtlar</h2>
                    <p class="p-heading">Vakolatli mutaxassis hech qachon mijozga xalaqit berishga, uning qadr-qimmatiga tajovuz qilishga, ichki muammosining ahamiyatini kamsitishga yo'l qo'ymaydi. Bemor bilan muloqot qilishda psixolog oldida u bilan kommunikativ
                         aloqa o'rnatish va bemorning hissiy muammosini hal qilish uchun eng mos texnikani topish vazifasi turadi.</p>
                </div>
            </div><br><br>


        <div class="container" >
            <div class="row">
            <?php
                  while($row =mysqli_fetch_assoc($query)){
              ?>
                <div class="col-lg-4">
                <a href="posts.php?id=<?=$row['id']?>" style="text-decoration: none">
                    <div class="text-container">
                        <div class="image-container">
                           
                                <img class="img-fluid" src="../images/<?=$row['img']?>" alt="alternative">
                            
                        </div> 
                        <p>Ism: <?=$row['ism']?>;<br>
                        <?=$row['about']?>
                    </p>
                    </div> 
                    </a>
                </div> 
                <?php
                  }
                ?>
            </div> 
        </div> 
    </div> 