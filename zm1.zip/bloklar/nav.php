<nav class="navbar navbar-expand-lg fixed-top navbar-dark">
        <div class="container">
            

            <p class="navbar-brand logo-image">Yordam</p>  

            <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#header">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#services">Servis</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="#therapists">Terapevtlar</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll" href="../admin/jadval1.php">Terapevtlar uchun</a>
                    </li>
                </ul>
                <span class="nav-item social-icons">
                    <span class="fa-stack">
                        <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-facebook-f fa-stack-1x"></i>
                        </a>
                    </span>
                    <span class="fa-stack">
                        <a href="#your-link">
                            <i class="fas fa-circle fa-stack-2x"></i>
                            <i class="fab fa-twitter fa-stack-1x"></i>
                        </a>
                    </span>
                </span>
            </div> 
        </div>
    </nav> 