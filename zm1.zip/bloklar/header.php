<header id="header" class="header" >
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-container">
                        <h1 class="h1-large">Ruhiy sog' bo'lishingizga yordam beramiz</h1>
                        <a class="btn-solid-lg page-scroll" href="#services">Biz haqimizda</a>
                        <a class="btn-outline-lg page-scroll" href="../admin/registratsiya.php"><i class="fas fa-user"></i>Yozilish</a>
                    </div> 
                </div> 
            </div>
        </div>
    </header> 