<div id="services" class="basic-2">
        <div class="container">
        <div class="row">
                <div class="col-lg-12">
                <h2 class="h2-heading">Psixologiya </h2>
                    <p class="p-heading">inson faoliyati va hayvonlar xatti-harakati jarayonida voqelikning psixik aks etishi, ruhiy jarayonlar, holatlar, hodisalar, hislatlar toʻgʻrisidagi fan. Psixologiyaning tadqiqot predmetiga sezgilar va idrok obrazlari, 
                        tafakkur va hissiyot, faoliyat va muomala kabi psixologik jarayonlar, kategoriyalar kiradi.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="text-box">
                        
                        <h4>Eshitish</h4>
                        <p>Klinik psixologiya psixologiyaning murakkab sohalaridan biridir. U shaxsning shaxsiyatini, uning ichki dunyosini, his-tuyg'ularini va kechinmalarini ruhiy kasalliklar
                             yoki buzilishlar bilan aloqasi nuqtai nazaridan o'rganish va tashxislashga qaratilgan.</p>
                    </div> <!-- end of text-box -->
                </div> <!-- end of col -->
                <div class="col-lg-4">
                    <div class="text-box">
                    
                        <h4>Yordam berish</h4>
                        <p>Klinik psixolog - bu o'z bemorlariga og'ir asabiy buzilishlar, jarohatlar oqibatlaridan xalos bo'lishga, ichki xotirjamlikni topishga
                             va muayyan travmatik vaziyatlardan keyin ruhiy tiklanishiga yordam beradigan mutaxassis. Klinik psixologiya psixiatriya bilan chegaradosh</p>
                    </div> <!-- end of text-box -->
                </div> <!-- end of col -->
                <div class="col-lg-4">
                    <div class="text-box">
                     
                        <h4>Maslahat berish</h4>
                        <p>Hozirgi vaqtda psixologlarning roli juda muhim - ko'plab korxonalar, maktablar, oliy o'quv yurtlari ushbu mutaxassislarsiz ishlay olmaydi.
                             Ish jarayonida yuzaga keladigan nizolar va tushunmovchiliklarning aksariyatini psixologlar hal qiladi. ishi odamlar bl muloqotga asoslangan.</p>
                    </div> <!-- end of text-box -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of basic-2 -->